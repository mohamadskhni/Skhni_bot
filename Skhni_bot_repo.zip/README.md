# Skhni_bot – بوت إشارات تلقائي لـ Pocket Option

تم تطوير هذا البوت من قبل **Mohamad Dib Skhni**.

## وظيفة البوت
يستقبل إشارات تداول من مصادر خارجية (مثل TradingView) ويحولها إلى رسائل مرسلة تلقائيًا عبر Telegram باستخدام البوت: [@Skhni_bot](https://t.me/Skhni_bot)

## كيفية الاستخدام

1. إرسال POST إلى `/signal`
2. سيتم إرسال إشعار بتنسيق احترافي إلى معرف Telegram الخاص بك

## مثال إرسال إشارة:

```bash
curl -X POST https://your-bot-url.onrender.com/signal \
-H "Content-Type: text/plain" \
-d "action: SELL
symbol: GBPUSD
price: 1.2520
timeframe: 1m"
```

## معلومات الاتصال
- الاسم: **Mohamad Dib Skhni**
- اللغة: Deutsch (`de`)
